const $=id=>document.getElementById(id);
const STORE="avmp_v3_projects";
function makePrompt(){
 const topic=$("topic").value.trim(); if(!topic){$("topic").focus();$("status").textContent="Enter a topic";return;}
 const lang=$("language").value, format=$("format").value, duration=$("duration").value, style=$("style").value, voice=$("voice").value;
 const prompt=`Create a ${duration} ${format} video about: ${topic}.\nVisual style: ${style}.\nNarration: ${voice}.\nLanguage: ${lang}.\nUse clear scene progression, visually consistent subjects, smooth camera movement, realistic lighting, high detail, and accurate educational information. Add captions only if supported by the video tool. Do not add watermarks.`;
 $("output").value=prompt; $("status").textContent="Prompt ready";
}
function getSaved(){try{return JSON.parse(localStorage.getItem(STORE)||"[]")}catch{return []}}
function setSaved(items){localStorage.setItem(STORE,JSON.stringify(items));renderSaved()}
function save(){if(!$("output").value.trim()){makePrompt();if(!$("output").value.trim())return;}const items=getSaved();items.unshift({id:Date.now(),topic:$("topic").value.trim(),prompt:$("output").value});setSaved(items.slice(0,20));$("status").textContent="Project saved on this device";}
function renderSaved(){const root=$("saved"),items=getSaved();root.innerHTML="";if(!items.length){root.className="saved empty";root.textContent="अभी कोई project save नहीं है।";return;}root.className="saved";items.forEach(item=>{const div=document.createElement("div");div.className="saved-item";const title=document.createElement("span");title.textContent=item.topic||"Untitled project";const group=document.createElement("div");const open=document.createElement("button");open.className="secondary";open.textContent="Open";open.onclick=()=>{$("topic").value=item.topic;$("output").value=item.prompt;$("status").textContent="Saved project opened";window.scrollTo({top:0,behavior:"smooth"})};const del=document.createElement("button");del.className="secondary";del.textContent="Delete";del.onclick=()=>setSaved(getSaved().filter(x=>x.id!==item.id));group.append(open,del);div.append(title,group);root.append(div)})}
$("build").onclick=makePrompt;$("save").onclick=save;
$("copy").onclick=async()=>{if(!$("output").value)return;try{await navigator.clipboard.writeText($("output").value);$("status").textContent="Copied"}catch{$("output").select();$("status").textContent="Select and copy"}};
$("download").onclick=()=>{if(!$("output").value)return;const blob=new Blob([$("output").value],{type:"text/plain"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="video-prompt.txt";a.click();URL.revokeObjectURL(a.href)};
renderSaved();
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));